package hu.u_szeged.dep.util;

public class EmptyNodeEvaluator {
  public static final String EMPTY_LABEL = "_";
  public static final int GS_PARENT_COLUMN = 8;
  public static final int PRED_PARENT_COLUMN = 9;
  public static final int GS_LABEL_COLUMN = 10;
  public static final int PRED_LABEL_COLUMN = 11;
  public static final String SEPARATOR = "@";
}
