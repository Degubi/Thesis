package hu.u_szeged.eval.resource;

/**
 * Created by zsibritajanos on 2015.11.02..
 */
public class Resource {
}
