package hu.u_szeged.util;

public class SpecialCharacters {

	public static final String POS_SEPARATOR = "##";
}
